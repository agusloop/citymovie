<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
	<title></title>
		
    <!-- viewport: se utiliza para controlar cómo aparecerá el contenido HTML
         en los navegadores móviles, de esta forma nos aseguramos que el contenido 
         se ajusta al ancho del dispositivo.
         En este caso estamos indicando que el contenido tendrá el ancho del dispositivo
         y que la escala inicial es de 1 -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	
    <meta name="author" content="Agustin Lopez Aguilar ---- ALA">

</head>
<body>
	<section class="SecUno">
	    <div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
	    <div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
		<div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
		<div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
		<div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
		<div class="articulos">
		<article>
			<h2 class="NomArt">Articulos</h2>
			<p >Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse id explicabo iste nam suscipit, ut nemo, officiis repellat animi voluptatibus dolore quidem minima quam impedit excepturi aliquam! Reiciendis, repudiandae labore?</p>
		</article>
		</div>
		
	
		
	</section>



</body>
</html>